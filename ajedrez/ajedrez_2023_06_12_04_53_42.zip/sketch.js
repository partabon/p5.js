let img;

function preload(){
  img=loadImage('Chess_Pieces_Sprite.png');
}

function setup() {
  createCanvas(500, 500);  
    let p = new Pieza();
  //console.log(p.Blanca);
}


function draw() {
  var colorCuadro;
  var colorClaro=color(212,212,185);
  var colorOscuro=color(151,108,93) ;
  var posicion;
  let tamaño=50;
  
  background(60);
  
  noStroke();
  for (let col=0; col<8; col++){
    for(let ren=0;ren<8;ren++){
        let esCuadradoClaro=(col+ren)%2!=0;
        if(esCuadradoClaro)  colorCuadro= colorClaro;
        else  colorCuadro= colorOscuro;
        fill(colorCuadro)
        square(50+col*tamaño,50+ren*tamaño,tamaño) 
        }
  }

  image(img,25,25,360,160);

}
  //square(30, 20, 55);