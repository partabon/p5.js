class Tablero {
 

  constructor(){
    let pieza = new Pieza();
    this.Casilla = new Array(64);
    this.Casilla[0]=pieza.Blanca | pieza.Alfil;
    
    console.log(pieza.Blanca | pieza.Alfil);
    this.Casilla [63]=pieza.Negra | pieza.Dama;
    this.Casilla [7]=pieza.Negra | pieza.Caballo;
    //this.Casilla [7]=pieza.Negra | pieza.Caballo;
  }

  
}



let T = new Tablero();
console.log(T);