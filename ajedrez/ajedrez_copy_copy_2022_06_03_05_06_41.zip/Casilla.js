class Casilla {
  // A cell object knows about its location in the grid
  // as well as its size with the variables x,y,w,h
  // let this.x,this.y;   // x,y location
  // let this.w,this.h;   // width and height
  // let this.angle; // angle for oscillating brightness

  // Cell Constructor
  constructor(tempX, tempY, tempW, tempH, tempColor) {
    this.x = tempX;
    this.y = tempY;
    this.w = tempW;
    this.h = tempH;
    //this.pieza = 0;
    this.colorCasilla=tempColor;
    
  }


  display() {
    noStroke();
    // Color calculated using sine wave
    fill(this.colorCasilla);
    rect(this.x,this.y,this.w,this.h);
    // if (this.pieza>0) {
    //   let imgPieza = 'assets\' + str(this.pieza) + '.png' ;
    //   imageMode(CORNER);
    //   img(this.x,this.y,this.w,this.h);
    //}
  }

}

