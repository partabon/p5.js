
class Pieza {
  
  constructor(){
    this.Ninguno=0;
    this.Rey=1;
    this.Peon=2;
    this.Caballo=3;
    this.Alfil=4;
    this.Torre=5;
    this.Dama =6;
    
    this.Blanca =8;
    this.Negra =16;
  }
}


// let p = new Pieza();
// console.log(p.Ninguno);
// expected output: 12
