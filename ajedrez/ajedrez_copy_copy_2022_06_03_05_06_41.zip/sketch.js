let img=[];
let p ;
let T;
let tamaño = 50;

function preload(){
  let imgPieza;
  for (let i =9;i<=14;i++){
    imgPieza = 'assets/'+ i +'.png';
    img[i]=loadImage(imgPieza);
  }
  
  for (let i =17;i<=22;i++){
    imgPieza = 'assets/'+ i +'.png';
    img[i]=loadImage(imgPieza);
  }

 // print(imgPieza);
  
}

function setup() {
  createCanvas(500, 500);  
  p = new Pieza();
  T= new Tablero();
  //console.log(p.Blanca);  
  
  
}


function draw() {
  background(60);

  
  T.show();
  T.showSprites();
 
}
  //square(30, 20, 55);


