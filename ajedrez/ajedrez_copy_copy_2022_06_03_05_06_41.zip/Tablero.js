class Tablero {
  
  constructor() {
    let pieza = new Pieza();
    
    this.casilla = new Array(64);
    for(let i=0;i<64;i++){
      this.casilla[i] =0;
    }
    
    this.casilla[0] = pieza.Blanca | pieza.Alfil;
    this.casilla[63] = pieza.Negra | pieza.Dama;
    this.casilla[7] = pieza.Negra | pieza.Caballo;
  }

  show() {
    let malla=[];
    var colorCuadro;
    var colorClaro = color(212,212,185) ;
    var colorOscuro = color(151,108,93);
    var posicion;
     noStroke();
    
    for (let col = 0; col < 8; col++) {
      for (let ren = 0; ren < 8; ren++) {
        let esCuadradoClaro = (col + ren) % 2 != 0;
        if (esCuadradoClaro) colorCuadro = colorClaro;
        else colorCuadro = colorOscuro;
        
        malla[ren*8+col] = new Casilla(50+col*tamaño,50 + ren * tamaño,tamaño,tamaño,colorCuadro); 
        malla[ren*8+col].display();
      }
    }
  }
    
    //coloca los sprites
    showSprites(){
      let  col,ren;
      let pieza = new Pieza();
  
    for (let n=0; n<64;n++){
      if(this.casilla[n]>0){
       col=n % 8;
       ren= 7-int(n/8);
       image(img[this.casilla[n]],50+col*tamaño,50 + ren * tamaño,tamaño,tamaño);
      }
    }
      
//       p=pieza.Blanca | pieza.Alfil;
//     let n=0;
//       col=n % 8;
//       ren= 7-int(n/8);
//     image(img[p],50+col*tamaño,50 + ren * tamaño,tamaño,tamaño);
  
//    n=63;
//    col=n % 8;
//    ren= 7-int(n/8);
//    p= pieza.Negra | pieza.Dama;
//    image(img[p],50+col*tamaño,50 + ren * tamaño,tamaño,tamaño);
  
  
//     n=7;  
//     col=n % 8;
//    ren= 7-int(n/8);
//     p= pieza.Negra | pieza.Caballo;
//     image(img[p],50+col*tamaño,50 + ren * tamaño,tamaño,tamaño);
  


      // for (let col = 0; col < 8; col++) {
      // for (let ren = 0; ren < 8; ren++) {
      // if (this.pieza>0) {
    //   let imgPieza = 'assets\' + str(this.pieza) + '.png' ;
    //   imageMode(CORNER);
    //   img(this.x,this.y,this.w,this.h);
    //}
      
    }
  
    cargarPosicionFEN(fen){
      let simbolo;
      let colorPieza;
      let tipoPieza;
       let p =new Pieza();
       let tipoPiezadeSimbolo =  createStringDict({'k': p.Rey ,    'p': p.Peon,
                                                   'c': p.Caballo ,'a': p.Alfil,
                                                   't': p.Torre ,  'd': p.Dama});
      tableroFen = split(fen,' ')[0];
      let col=0, ren=7;
      
      for(let i =0; i<tableroFen.length; i++) {
         simbolo=tableroFen[i];
        if(simbolo=='/'){
          col=0;
          ren--;
        } else{
          if(Number.isInteger(simbolo)){
            col+=int(simbolo) ;   
          } else{
            colorPieza = simbolo==simbolo.toUpperCase() ? p.Blanca : p.Negra;
            tipoPieza  = tipoPiezadeSimbolo.get(simbolo.toLowerCase());
            this.casilla[ren * 8 + col] = tipoPieza | colorPieza;
            col++;
          }
          
        }
      }     
  
   }
}  
    
  


// let T = new Tablero();
// console.log(T);
