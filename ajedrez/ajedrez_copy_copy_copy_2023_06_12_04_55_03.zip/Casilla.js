class Casilla {
  // A cell object knows about its location in the grid
  // as well as its size with the variables x,y,w,h
  // let this.x,this.y;   // x,y location
  // let this.w,this.h;   // width and height
  // let this.angle; // angle for oscillating brightness

  // Cell Constructor
  constructor(tempX, tempY, tempW, tempH, tempColor) {
    this.x = tempX;
    this.y = tempY;
    this.w = tempW;
    this.h = tempH;
    //this.pieza = 0;
    this.colorCasilla=tempColor;
    
  }


  display() {
    noStroke();
    // Color calculated using sine wave
    fill(this.colorCasilla);
    rect(this.x,this.y,this.w,this.h);
    if (this.pieza>0) {
      let imgPieza = 'assets\' + str(this.pieza) + '.png' ;
      imageMode(CORNER);
      img(this.x,this.y,this.w,this.h);
    }
  }
}


// 2D Array of objects
let grid = [] ; //array of Cells

// Number of columns and rows in the grid
let cols = 10;
let rows = 10;

function setup() {
  createCanvas(200,200);

  for (let i = 0; i < cols; i++) {
    grid[i] =[];
    for (let j = 0; j < rows; j++) {
      // Initialize each object
      grid[i][j] = new Cell(i*20,j*20,20,20,i+j);
    }
  }
}

function draw() {
  background(0);
  // The counter variables i and j are also the column and row numbers and
  // are used as arguments to the constructor for each object in the grid.
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      // Oscillate and display each object
      grid[i][j].oscillate();
      grid[i][j].display();
    }
  }
}

