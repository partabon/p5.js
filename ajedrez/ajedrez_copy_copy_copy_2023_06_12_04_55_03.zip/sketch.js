let img;
let p ;
let T;

function preload(){
  //for (let i =)
  img=loadImage('Chess_Pieces_Sprite.png');
}

function setup() {
  createCanvas(500, 500);  
  p = new Pieza();
  T= new Tablero();
  //console.log(p.Blanca);
}


function draw() {
  background(60);
  var colorCuadro;
  var colorClaro=color(238,224,224);
  var colorOscuro=color(112,68,26) ;
  var posicion;
  let tamaño=50;
  

  T.show();
  
 // 
 
  //image(img,25,25,360,160);

}
  //square(30, 20, 55);