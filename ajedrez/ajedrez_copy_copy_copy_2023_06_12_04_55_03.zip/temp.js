 
// 2D Array of objects
let grid = [] ; //array of Cells

// Number of columns and rows in the grid
let cols = 10;
let rows = 10;

function setup() {
  createCanvas(200,200);

  for (let i = 0; i < cols; i++) {
    grid[i] =[];
    for (let j = 0; j < rows; j++) {
      // Initialize each object
      grid[i][j] = new Cell(i*20,j*20,20,20,i+j);
    }
  }
}

function draw() {
  background(0);
  // The counter variables i and j are also the column and row numbers and
  // are used as arguments to the constructor for each object in the grid.
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      // Oscillate and display each object
      grid[i][j].oscillate();
      grid[i][j].display();
    }
  }
}

