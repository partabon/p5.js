class Tablero {
  
  constructor() {
    
    let pieza = new Pieza();
    this.casilla = new Array(64);
    
    this.casilla[0] = pieza.Blanca | pieza.Alfil;

    //console.log(pieza.Blanca | pieza.Alfil);
    this.casilla[63] = pieza.Negra | pieza.Dama;
    this.casilla[7] = pieza.Negra | pieza.Caballo;
  }

  show() {
    let malla=[];
    var colorCuadro;
    var colorClaro = color(212,212,185);
    var colorOscuro = color(151,108,93);
    var posicion;
    let tamaño = 50;
    noStroke();
    
    for (let col = 0; col < 8; col++) {
      for (let ren = 0; ren < 8; ren++) {
        let esCuadradoClaro = (col + ren) % 2 != 0;
        if (esCuadradoClaro) colorCuadro = colorClaro;
        else colorCuadro = colorOscuro;
        //fill(colorCuadro);
        this.malla[col*8+j] = new Casilla(i*20,j*20,20,20,colorCuadro); 
        this.malla[i*8+j].display();
       // square(50 + col * tamaño, 50 + ren * tamaño, tamaño);
      }
    }
    
    //coloca los sprites
    
  }
  
}

// let T = new Tablero();
// console.log(T);
