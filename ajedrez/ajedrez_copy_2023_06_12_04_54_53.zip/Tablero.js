class Tablero {
  
  constructor() {
    let pieza = new Pieza();
    this.Casilla = new Array(64);
    this.Casilla[0] = pieza.Blanca | pieza.Alfil;

    //console.log(pieza.Blanca | pieza.Alfil);
    this.Casilla[63] = pieza.Negra | pieza.Dama;
    this.Casilla[7] = pieza.Negra | pieza.Caballo;
  }

  show() {
    var colorCuadro;
    var colorClaro = color(white);
    var colorOscuro = color(black);
    var posicion;
    let tamaño = 50;
    noStroke();
    for (let col = 0; col < 8; col++) {
      for (let ren = 0; ren < 8; ren++) {
        let esCuadradoClaro = (col + ren) % 2 != 0;
        if (esCuadradoClaro) colorCuadro = colorClaro;
        else colorCuadro = colorOscuro;
        fill(colorCuadro);
        square(50 + col * tamaño, 50 + ren * tamaño, tamaño);
      }
    }
  }
}

// let T = new Tablero();
// console.log(T);
