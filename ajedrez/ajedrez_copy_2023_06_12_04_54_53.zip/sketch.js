let img;

function preload(){
  img=loadImage('Chess_Pieces_Sprite.png');
}

function setup() {
  createCanvas(500, 500);  
    let p = new Pieza();
  //console.log(p.Blanca);
}


function draw() {
  var colorCuadro;
  var colorClaro=color(238,224,224);
  var colorOscuro=color(112,68,26) ;
  var posicion;
  let tamaño=50;
  
  let T= new Tablero();
  
  background(60);
 
  image(img,25,25,360,160);

}
  //square(30, 20, 55);