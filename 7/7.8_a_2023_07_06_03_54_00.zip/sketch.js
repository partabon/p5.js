let img;
let x =0;

function preload(){
  img =loadImage('kitten2.jpg')
}

function setup() {
  
  createCanvas(400, 400);
}

function draw() {
  background(220);
  image(img,x,0,mouseX,mouseY);
  x++;
}