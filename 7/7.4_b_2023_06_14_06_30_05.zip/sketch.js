let bubbles = [];
let bubble;

function setup() {
  createCanvas(600, 400);
  for (let i = 0; i < 5; i++) {
    let x = random(width);
    let y = random(height);
    let r = random(10, 50);
    b = new Bubble(x, y, r);
    bubbles.push(b);
  }
}

function draw() {
  background(0);
  for (let bubble of bubbles) {
    bubble.move();
    bubble.show();
  }
}

function mousePressed() {
  for (let bubble of bubbles) {
    bubble.clicked(mouseX,mouseY);
  } //
}

// function mousePressed() {
//   let r = random(10, 50);
//   let b = new Bubble(mouseX, mouseY, r);
//   bubbles.push(b);
//   //bubbles
// }

// function mouseDragged() {
//   let r = random(10, 50);
//   let b = new Bubble(mouseX, mouseY, r);
//   bubbles.push(b);
//   //bubbles
// }

class Bubble {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.brightness=0;
  }

  clicked(mx,my ) {
    let d = dist(mx, my, this.x, this.y);
    if (d < this.r) {
      console.log("Clicked!!");
    }
  }

  move() {
    this.x = this.x + random(-5, 5);
    this.y = this.y + random(-5, 5);
  }

  show() {
    stroke(255);
    //noStroke();
    strokeWeight(4);
    //noFill();
    fill(this.brightness,100);
    ellipse(this.x, this.y, this.r * 2);
  }
}
