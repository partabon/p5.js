let bubbles = [];
let bubble1;

let flower;

function preload() {
  flower = loadImage("kittens/flower.png");
}

function setup() {
  createCanvas(600, 400);
  for (i = 0; i < 20; i++) {
    let x = random(width);
    let y = random(height);
    let r = random(10, 50);
    bubbles[i] = new Bubble(x, y, r);
  }
  bubble1 = new Bubble(109, 109, 10);
}

function draw() {
  background(0);

  //  if (bubble1.intersects(bubble2)) {
  //    background(200, 0, 100);
  //  }
  bubble1.x = mouseX;
  bubble1.y = mouseY;
  for (let b of bubbles) {
    b.show();
    b.move();
    let overlapping = false;
    for (let other of bubbles) {
      if (b.intersects(other) && b !== other) overlapping = true;
      if (overlapping) b.cambiaColor(255);
      else b.cambiaColor(0);
    }
    //   // else b.cambiaColor(0);
    // }

    //bubble1.show();
  }
}

function mouseDragged() {
  //for (let i = 0; i < 5; i++) {

  b = new Bubble(mouseX, mouseY, r);
  bubbles.push(b);
  // }
}

class Bubble {
  constructor(x, y, r = 50) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.brightness = 0;
  }

  cambiaColor(c) {
    //if (this.brightness==0)
    this.brightness = c;
    //else
    //   this.brightness=0;
  }

  contains(mx, my) {
    let d = dist(mx, my, this.x, this.y);
    return d < this.r;
    //console.log("Clicked!!");
  }

  intersects(other) {
    let d = dist(this.x, this.y, other.x, other.y);
    return d < this.r + other.r;
  }

  move() {
    this.x = this.x + random(-2, 2);
    this.y = this.y + random(-2, 2);
  }

  show() {
    image(flower, this.x, this.y, this.r * 2, this.r * 2);
    //   stroke(255);
    //   //noStroke();
    //   strokeWeight(4);
    //   //noFill();
    //   fill(this.brightness, 100);
    //   ellipse(this.x, this.y, this.r * 2);
  }
}
