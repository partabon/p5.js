var words=["rainbow","heart","purple","friendship"];
var nums = [100, 25, 46, 72];
var num = 23;

var index=0;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(100);
  fill(255);
  textSize(32);
  text(words[index],12,200);
  
  for(var i=0;i<nums.length;i++){
    ellipse(10+i*50,300,nums[i]);
  }
  ellipse(100,200,num);
  //ellipse(200,200,nums[2]);
   
}

function mousePressed(){
  index++;
  if(index==words.length)
    index=0;
}
