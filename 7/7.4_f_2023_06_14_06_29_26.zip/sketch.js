let cuadros = [];
let cuadro;

function setup() {
  createCanvas(600, 400);
  for (let i = 0; i < 5; i++) {
    let r = random(20, 50);
    let x = random(width);
    let y = random(height);
    b = new Cuadro(x, y, r);
    cuadros.push(b);
  }
}

function draw() {
  background(0);
   for (let cuadro of cuadros) {
   //cuadro.move();
     cuadro.show();
     //cuadro.cambiaColor(mouseX,mouseY);
   }
}

function mousePressed() {
  for (let cuadro of cuadros) {
    cuadro.cambiaColor(mouseX,mouseY);
  } //
}


class Cuadro {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.brightness=0;
  }
  

  cambiaColor(mx,my){
    let dx=abs(mx-(this.x+this.r));
    let dy=abs(my-(this.y+this.r));
    if (dx < this.r && dy<this.r) {
      if (this.brightness==0)
         this.brightness=255;
       else
         this.brightness=0;
       console.log("Clicked!!");
     }
  }

  move() {
    this.x = this.x + random(-5, 5);
    this.y = this.y + random(-5, 5);
  }

  show() {
    stroke(255);
    //noStroke();
    strokeWeight(4);
    //noFill();
    fill(this.brightness,100);
    rect(this.x, this.y, this.r*2);
  }
}
