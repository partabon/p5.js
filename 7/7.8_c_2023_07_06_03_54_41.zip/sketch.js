let bubbles = [];

let flower;
let kittens = [];

function preload() {
  flower = loadImage("kittens/flower.png");
  for (let i=0; i<5; i++)
    kittens[i]= loadImage(`kittens/kitten${i}.jpg`)
}

function setup() {
  createCanvas(600, 400);
  for (let i = 0; i < 20; i++) {
    let x = random(width);
    let y = random(height);
    let r = random(40, 60);
    let kitten =random(kittens)
    bubbles[i] = new Bubble(x, y, r, kitten);
  }

}

function draw() {
  background(0);

  for (let b of bubbles) {
    b.show();
    b.move();
  }
}

function mousePressed() {
  for (let i=0; i < bubbles.length; i++) 
    bubbles[i].clicked(mouseX,mouseY);
}



class Bubble {
  constructor(x, y, r, img) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.kitten = img;
  }

  clicked(px,py){
    let x1=this.x;
    let x2= this.x + 2*this.r;
    let y1 =this.y;
    let y2 = this.y +2*this.r;
    if (x1 < px && px < x2 && y1 < py && py < y2 ) {
      //console.log('click');
      this.kitten =random(kittens);
      
    }
  }
  
  move() {
    this.x = this.x + random(-2, 2);
    this.y = this.y + random(-2, 2);
  }

  show() {
    image(this.kitten, this.x, this.y, this.r * 2, this.r * 2);
  }
}
