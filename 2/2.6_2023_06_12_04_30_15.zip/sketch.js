let x = 100;
let y = 100;
let extraCanvas;

function setup() {
  createCanvas(200, 150);
  extraCanvas = createGraphics(200, 150);
  extraCanvas.clear();
  //extraCanvas.background(255,0,0);
  background(0);
}

function draw() {
  //trails!! 
   background(0);
  if (mouseIsPressed) {
    extraCanvas.fill(255, 100);
    extraCanvas.noStroke();
    extraCanvas.ellipse(mouseX, mouseY, 20, 20);
  }

  //No trails
  image(extraCanvas, 0, 0);
  x += random(-2, 2);
  y += random(-2, 2);
  stroke(255);
  fill(255, 0, 0);
  rectMode(CENTER);
  rect(x, y, 10, 10);
   
}