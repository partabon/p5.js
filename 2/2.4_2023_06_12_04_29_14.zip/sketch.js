var col = 0;

var circle1 = {
  x: 0,
  y: 200,
  diameter: 50
};

var circle2 = {
  x: 0,
  y: 200,
  diameter: 50
};

var r = 0;
var g = 20;
var b = 255;


function setup() {
  createCanvas(600, 400);
}

function draw() {
  r = map(mouseX,0,600,0,255);
  b =map(mouseX,0,600,255,0);
  background(r,0,b);
  fill(255, 0, 0);
  ellipse(mouseX, circle1.y, circle1.diameter);
  circle1.x = circle1.x + 1;
}