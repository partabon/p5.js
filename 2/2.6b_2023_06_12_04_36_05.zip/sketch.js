let x = 150;
let y = 75;
let extraCanvas;

function setup() {
  createCanvas(300, 150);
  extraCanvas = createGraphics(300, 150);
  extraCanvas.clear();
  //extraCanvas.background(255,0,0);
  background(255);
}

function draw() {
  //trails!! 
   background(255);
  if (mouseIsPressed) {
    extraCanvas.fill(0, 100);
    extraCanvas.noStroke();
    extraCanvas.ellipse(mouseX, mouseY, 2, 2);
  }

  //No trails
  image(extraCanvas, 0, 0);
  x += random(-2, 2);
  y += random(-2, 2);
  stroke(255);
  fill(255, 0, 0);
  rectMode(CENTER);
  rect(x, y, 10, 10);
   
}