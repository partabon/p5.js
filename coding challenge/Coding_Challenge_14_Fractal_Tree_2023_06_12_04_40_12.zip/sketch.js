//const PI =3.141592;
var slider;
var angle = 0;
var len = 40;

function setup() {
  createCanvas(300, 120);
  slider = createSlider(0, PI/2, PI / 4, 0.01);

}

function draw() {
  background(51);
  angle = slider.value();

  stroke(255);
  translate(150, height);
  // line(200,height,200, height-len);
  branch(len);

}


function branch(len) {
  line(0, 0, 0, -len);
  translate(0, -len);


  if (len > 4) {
    push();
    rotate(angle);
    branch(len * 0.667);
    pop();
    rotate(-angle);
    branch(len * 0.667);
  }

}