let snow = [];
let gravituy;

function setup() {
  createCanvas(windowWidth, windowHeight);
  gravity = createVector(0, 0.03);
}

function draw() {
  background(0);
  snow.push(new Snowflake());

  for (flake of snow) {
    flake.applyForce(gravity);
    
    flake.render();
    flake.update();
  }
  
  for(let i=snow.length-1;i>=0;i--){
    if(snow[i].offScreen()){
      snow.splice(i,1);
    }
  }
  
}