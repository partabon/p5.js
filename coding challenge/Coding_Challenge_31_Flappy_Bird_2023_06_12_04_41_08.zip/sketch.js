var bird;

function setup() {
  createCanvas(400, 600);
  bird = new Bird();
   //console.log("SPACE");
}

function up (){
  
}

function draw() {
  background(0);
  bird.show();
  bird.update();
}

function keyPressed() {
  if (key == " ") {
    bird.up();
    //console.log("SPACE");
  }
}