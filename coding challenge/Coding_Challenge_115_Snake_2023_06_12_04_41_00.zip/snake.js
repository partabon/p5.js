class Snake {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.xspeed = 0;
    this.yspeed = 0;
    this.total = 0;
    this.tail = [];
  }

  dir(x, y) {
    this.xspeed = x;
    this.yspeed = y;
  }

  update() {
    for (var i = 0; i < total; i++) {
      tail[i]=tail[i+1];      
    }
    tail[total-1]=createVector(this.x,this.y);
    this.x = this.x + this.xspeed * scl;
    this.y = this.y + this.yspeed * scl;

    this.x = constrain(this.x, 0, width - scl);
    this.y = constrain(this.y, 0, height - scl);
  
  }

  eat(pos) {
    var d = dist(this.x, this.y, pos.x, pos.y);
    if (d < 1) {
      total++;
      return true;
    } else {
      return false;
    }
  }

  show() {
    fill(255);
    //rectMode(CENTER);
    for (var i = 0; i < total; i++) {
    rect(this.tail[i].x, this.tail[i].y, scl, scl);
      
  }
}
