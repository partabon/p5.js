let scl = 20; //scale
let w = 1000;
let h = 800;

let flying = 0;

let terrain = [];


function setup() {
  createCanvas(600, 600, WEBGL);

  cols = floor(w / scl - 1);
  rows = floor(h / scl - 1);

  for (let x = 0; x < cols; x++)
    terrain[x] = [];
  console.log(width);
}

function draw() {

  flying -= 0.02;

  let yoff = flying;

  for (let y = 0; y < rows; y++) {
    let xoff = 0;
    for (let x = 0; x < cols; x++) {
      terrain[x][y] = map(noise(xoff, yoff), 0, 1, -100, 100);
      xoff += 0.2;
    }
    yoff += 0.2;
  }


  background(0);
  noFill();
  stroke(255);


  translate(30, 0);
  rotateX(PI / 3);
  translate(-w / 2, -h / 2);
  //frameRate(20);


  for (let y = 0; y < rows - 1; y++) {
    beginShape(TRIANGLE_STRIP);
    for (let x = 0; x < cols; x++) {
      vertex(x * scl, y * scl, terrain[x][y]);
      vertex(x * scl, (y + 1) * scl, terrain[x][y + 1]);
    }
    endShape();
  }
}