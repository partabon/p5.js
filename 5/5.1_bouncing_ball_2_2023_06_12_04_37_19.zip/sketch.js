let x=7,speedX=2;
let y=11, speedY=2.5;

function setup() {
  createCanvas(300, 150);

}

function draw() {
  //trails!! 
  background(0);

  stroke(255);
  strokeWeight(4);
  noFill();
  ellipse(x, y, 10, 10);
  
  if (x >width || x<0){
    speedX =speedX*-1;
  }
  
    if (y >height || y<0){
    speedY =speedY*-1;
  }
    y=y+speedY;
    x=x+speedX;
    // fill(255, 0, 200);


  // ellipse(300, 200, 100, 100);
  //rectMode(CENTER);
  //rect(mouseX, mouseY, 10, 10);

}