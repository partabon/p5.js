var ball = {
  x: 10,
  xspeed: 4,
  y: 75,
  yspeed: -3
}

function setup() {
  createCanvas(300, 150);
}

function draw() {
  background(0);
  display();
  bounce();
  move();
}

function move() {
  ball.y += ball.yspeed;
  ball.x += ball.xspeed;
}

function bounce() {
  if (ball.x > width || ball.x < 0) {
    ball.xspeed *= -1;
  }

  if (ball.y > height || ball.y < 0) {
    ball.yspeed *= -1;
  }
}

function display() {
  stroke(255);
  strokeWeight(4);
  fill(255,0,255);
  ellipse(ball.x, ball.y, 12, 12);
}