function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  fill(255,0,0);
  rect(100,100,50,50);
  
}