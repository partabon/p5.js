var speed=3;

function setup() {
  createCanvas(300, 150);

}

function draw() {
  //trails!! 
  background(0);

  stroke(255);
  strokeWeight(4);
  noFill();
  
  var x=0;
  while(x<=width){
       ellipse(x, 75, 2, 2); 
    x=x+10;
  }      
 


  // ellipse(300, 200, 100, 100);
  //rectMode(CENTER);
  //rect(mouseX, mouseY, 10, 10);

}