let x=0,speed=3;

function setup() {
  createCanvas(300, 150);

}

function draw() {
  //trails!! 
  background(0);

  stroke(255);
  strokeWeight(4);
  noFill();
  ellipse(x, 75, 50, 50);
  
  if (x >width || x<0){
    speed =speed*-1;
  }
    x=x+speed;
    // fill(255, 0, 200);


  // ellipse(300, 200, 100, 100);
  //rectMode(CENTER);
  //rect(mouseX, mouseY, 10, 10);

}