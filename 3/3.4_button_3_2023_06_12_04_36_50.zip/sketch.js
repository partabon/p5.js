var on = false;

function setup() {
  createCanvas(300, 150);

}

function draw() {


  if (on && mousePressed) {
    background(0, 255, 0);
  } else {
    background(0);
  }
  
  stroke(255);
  noFill();
  strokeWeight(2);
    if (mouseX > 135 && mouseX < 165 && mouseY > 60 && mouseY < 90) {
   fill(255,0,200);  
    }

  rectMode(CENTER);
  rect(150, 75, 15, 15);
   
}


  function mousePressed() {
    if (mouseX > 135 && mouseX < 165 && mouseY > 60 && mouseY < 90) {
      on = !on;
      //background(0, 255, 0);
    }


}