
let song;

function preload() {
  song = loadSound('mover.mp3');
}

function setup() {
  createCanvas(710, 200);
  song.loop(); // la canción está lista para ser reproducida durante setup() porque fue cargada durante preload()
  background(0, 255, 0);
}

function mousePressed() {
  if (song.isPlaying()) {
    // .isPlaying() retorna una variable booleana
    song.pause(); // .play() continuará la reproducción desde la posición definida por .pause()
    background(255, 0, 0);
  } else {
    song.play();
    background(0, 255, 0);
  }
}
