// A Cell object
class Cell {
  // A cell object knows about its location in the grid
  // as well as its size with the variables x,y,w,h
   //var x,y;   // x,y location
  // let this.w,this.h;   // width and height
  // let this.angle; // angle for oscillating brightness

  // Cell Constructor
  constructor(tempX, tempY, tempW, tempH, tempAngle) {
    this.x = tempX;
    this.y = tempY;
    this.w = tempW;
    this.h = tempH;
    this.angle = tempAngle;
  }

  // Oscillation means increase angle
  oscillate() {
    this.angle += 0.02;
  }

  display() {
    stroke(255);
    // Color calculated using sine wave
    fill(127+127*sin(this.angle));
    rect(this.x,this.y,this.w,this.h);
    //point(this.x,this.y);
  }
}

// 2D Array of objects
let grid = [] ; //array of Cells

// Number of columns and rows in the grid
let cols = 10;
let rows = 10;
let count;

function setup() {
  createCanvas(200,200);
  count=cols*rows;
  //grid = new Cell[cols][rows];
  
  let index=0;
  for (let i = 0; i < cols; i++) {
    //grid[i] =[];
   for (let j = 0; j < rows; j++) {
      // Initialize each object
      grid[index++] = new Cell(i*20,j*20,20,20,i+j);
    //print(grid[i]);
    }
  }

}

function draw() {
  background(0);
  // The counter variables i and j are also the column and row numbers and
  // are used as arguments to the constructor for each object in the grid.
  for (let i = 0; i < count; i++) {
 //  for (let j = 0; j < rows; j++) {
      // Oscillate and display each object
      grid[i].oscillate();
      grid[i].display();
   // }
  }
}

