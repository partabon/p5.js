//posicion caja rosa
let bx; 
let by;
//posicion  cuadto
let ax;
let ay;
let cx;
let cy;
let col;
let ren;
let xinicial;
let yinicial;
let sonidomover;

let boxSize = 45;//mitad de tamaño del cuadro

let overBox = false;
let locked = false;
let xOffset = 0.0;
let yOffset = 0.0;
let movido =false;


function preload() {
  sonidomover = loadSound('mover.mp3');
}


function setup() {
  createCanvas(720, 400);
  bx = width / 2.0;
  by = height / 2.0; 
  ax=bx;
  ay=by;
  cx=bx;
  cy=by;
  rectMode(RADIUS);
  strokeWeight(2);
  let numcols=int(width/boxSize/2);
  //console.log(numcols);
  xinicial=bx-int(numcols/2)*boxSize*2+boxSize;
  
  let numrens=int(height/boxSize/2);
  //console.log(numrens);
  yinicial=by-int(numrens/2)*boxSize*2+boxSize;
  //console.log(xinicial,yinicial);
  
}

function draw() {
  background(237, 34, 93);
      stroke(10,0,10);
  
  for (let x=xinicial;x<width;x=x+boxSize*2){
    line(x,0,x,height);
  }
  
   for (let y=yinicial;y<height;y=y+boxSize*2){
    line(0,y,width,y);
  }
  //traza el cuadro
    stroke(52,52,190);
    fill(100);
  
    //rectangulo origen
    rect(ax, ay, boxSize, boxSize);  


  // Draw the box
  //antes normaliza la posición
  //rectangulo destino  
      fill(100);
    rect(cx, cy, boxSize, boxSize); 
  
  //rectangulo que se mueve
  fill(200);
  rect(bx, by, boxSize, boxSize);
  
  
}

function mousePressed() {

  xOffset = mouseX - bx;
  yOffset = mouseY - by;
}

function mouseDragged() {
 // if (locked) {
    bx = mouseX - xOffset;
    by = mouseY - yOffset;
 // }
}

function mouseReleased() {
  ax=cx;
  ay=cy;
  
  col=int((mouseX-xinicial)/(boxSize*2));
  ren=int((mouseY-yinicial)/(boxSize*2));
    console.log(col,ren);
  locked = false;
  
   //antes normaliza la posición
  bx=xinicial+(col*boxSize*2)+boxSize;
  by=yinicial+(ren*boxSize*2)+boxSize;
  
  sonidomover.play(); 
  cx=bx;
  cy=by;
  movido =true;
 
}
